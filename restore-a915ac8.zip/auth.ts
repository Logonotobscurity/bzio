export { authOptions, handlers, GET, POST, auth, signIn, signOut } from '@/lib/auth/config';
