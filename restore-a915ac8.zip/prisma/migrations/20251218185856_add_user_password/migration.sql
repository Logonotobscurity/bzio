-- AlterTable
ALTER TABLE "users" ADD COLUMN     "password" TEXT;
