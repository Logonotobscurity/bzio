-- AlterTable
ALTER TABLE "users" ADD COLUMN     "hashed_password" TEXT;
