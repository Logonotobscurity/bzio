import { GET, POST } from '@/lib/auth/config';

export const dynamic = 'force-dynamic';

export { GET, POST };
