export { default } from './customer-auth-content';
